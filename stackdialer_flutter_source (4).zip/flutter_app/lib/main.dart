import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'models/call_record.dart';
import 'models/contact.dart';
import 'screens/active_call_screen.dart';
import 'screens/stacked_recents_screen.dart';
import 'screens/t9_dialpad_screen.dart';
import 'screens/contacts_screen.dart';
import 'screens/insights_screen.dart';
import 'services/telecom_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF0D0C11),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const StackDialerApp());
}

class StackDialerApp extends StatelessWidget {
  const StackDialerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StackDialer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF141219),
        textTheme: GoogleFonts.plusJakartaSansTextTheme(
          ThemeData(brightness: Brightness.dark).textTheme,
        ),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF10B981),
          surface: Color(0xFF1E1C25),
        ),
      ),
      home: const MainDialerHost(),
    );
  }
}

class MainDialerHost extends StatefulWidget {
  const MainDialerHost({super.key});

  @override
  State<MainDialerHost> createState() => _MainDialerHostState();
}

class _MainDialerHostState extends State<MainDialerHost> {
  int _currentIndex = 0;
  List<CallRecord> _callLogs = [];
  List<ContactModel> _contacts = [];
  bool _isLoading = true;
  bool _hasActiveCallScreen = false;

  @override
  void initState() {
    super.initState();
    _initDeviceData();
    _setupTelecomInCallListener();
  }

  void _setupTelecomInCallListener() {
    TelecomService.setupCallListener((number, state) {
      if (!mounted) return;
      if (state == 'RINGING' && !_hasActiveCallScreen) {
        _openIncomingCallScreen(number);
      }
    });
  }

  Future<void> _initDeviceData() async {
    setState(() => _isLoading = true);
    await TelecomService.requestPermissions();
    final logs = await TelecomService.fetchDeviceCallLogs();
    final contacts = await TelecomService.fetchDeviceContacts();
    if (mounted) {
      setState(() {
        _callLogs = logs;
        _contacts = contacts;
        _isLoading = false;
      });
    }
  }

  void _openIncomingCallScreen(String number, [String? name]) {
    if (_hasActiveCallScreen) return;
    _hasActiveCallScreen = true;

    // Find contact name if matched
    final matched = _contacts.cast<ContactModel?>().firstWhere(
          (c) => c != null && c.number.replaceAll(RegExp(r'[^\d]'), '').endsWith(number.replaceAll(RegExp(r'[^\d]'), '')),
          orElse: () => null,
        );

    Navigator.of(context).push(
      PageRouteBuilder(
        opaque: true,
        transitionDuration: const Duration(milliseconds: 300),
        pageBuilder: (context, animation, secondaryAnimation) => ActiveCallScreen(
          phoneNumber: number,
          contactName: name ?? matched?.name,
          callerCategory: 'Personal',
          isIncoming: true,
          simSlot: 1,
          onCallEnded: (record) {
            _handleCompletedCall(record);
          },
        ),
        transitionsBuilder: (context, anim, secAnim, child) {
          return FadeTransition(opacity: anim, child: child);
        },
      ),
    ).then((_) {
      _hasActiveCallScreen = false;
    });
  }

  void _onCallNumber(String number, {int simSlot = 1}) async {
    HapticFeedback.heavyImpact();

    // Find contact name if exists
    final matched = _contacts.cast<ContactModel?>().firstWhere(
          (c) => c != null && c.number.replaceAll(RegExp(r'[^\d]'), '').endsWith(number.replaceAll(RegExp(r'[^\d]'), '')),
          orElse: () => null,
        );

    // Launch native carrier telephony call
    TelecomService.makeRealCall(number);

    // Immediately present the executive Outgoing ActiveCallScreen
    if (!_hasActiveCallScreen) {
      _hasActiveCallScreen = true;
      Navigator.of(context).push(
        PageRouteBuilder(
          opaque: true,
          transitionDuration: const Duration(milliseconds: 300),
          pageBuilder: (context, animation, secondaryAnimation) => ActiveCallScreen(
            phoneNumber: number,
            contactName: matched?.name,
            callerCategory: 'Work',
            simSlot: simSlot,
            isIncoming: false,
            onCallEnded: (record) {
              _handleCompletedCall(record);
            },
          ),
          transitionsBuilder: (context, anim, secAnim, child) {
            return SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 1),
                end: Offset.zero,
              ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
              child: child,
            );
          },
        ),
      ).then((_) {
        _hasActiveCallScreen = false;
      });
    }
  }

  void _handleCompletedCall(CallRecord record) {
    setState(() {
      _callLogs.insert(0, record);
    });
    // Also re-query device logs shortly
    Future.delayed(const Duration(seconds: 3), () {
      _initDeviceData();
    });
  }

  void _onSimulateIncomingCall() {
    _openIncomingCallScreen('+91 98201 45892', 'Alihosen Mondal');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141219),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF10B981)),
            )
          : IndexedStack(
              index: _currentIndex,
              children: [
                StackedRecentsScreen(
                  calls: _callLogs,
                  onRefresh: _initDeviceData,
                  onCallNumber: _onCallNumber,
                  onSimulateIncoming: _onSimulateIncomingCall,
                ),
                T9DialpadScreen(
                  contacts: _contacts,
                  onCallNumber: _onCallNumber,
                  onSimulateIncoming: _onSimulateIncomingCall,
                ),
                ContactsScreen(
                  contacts: _contacts,
                  onCallNumber: _onCallNumber,
                ),
                InsightsScreen(
                  calls: _callLogs,
                  onCallNumber: _onCallNumber,
                ),
              ],
            ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF121017).withOpacity(0.96),
          border: const Border(
            top: BorderSide(color: Colors.white10, width: 0.5),
          ),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (i) {
            HapticFeedback.selectionClick();
            setState(() => _currentIndex = i);
          },
          backgroundColor: Colors.transparent,
          elevation: 0,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: const Color(0xFF10B981),
          unselectedItemColor: Colors.white38,
          selectedFontSize: 11,
          unselectedFontSize: 11,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.layers_outlined),
              activeIcon: Icon(Icons.layers),
              label: 'Recents',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.dialpad_outlined),
              activeIcon: Icon(Icons.dialpad),
              label: 'Keypad',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.contacts_outlined),
              activeIcon: Icon(Icons.contacts),
              label: 'Contacts',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.analytics_outlined),
              activeIcon: Icon(Icons.analytics),
              label: 'Insights',
            ),
          ],
        ),
      ),
    );
  }
}
