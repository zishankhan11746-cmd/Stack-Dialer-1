class SpeedDialEntry {
  final int key; // 1 to 9
  final String name;
  final String number;

  const SpeedDialEntry({
    required this.key,
    required this.name,
    required this.number,
  });
}

class SpeedDialService {
  static final Map<int, SpeedDialEntry> _entries = {
    1: const SpeedDialEntry(key: 1, name: 'Voicemail', number: '*123#'),
    2: const SpeedDialEntry(key: 2, name: 'Mom ❤️', number: '+91 98201 45892'),
    3: const SpeedDialEntry(key: 3, name: 'Sanib Ansari', number: '+91 97654 21980'),
    4: const SpeedDialEntry(key: 4, name: 'Mo Faisal', number: '+91 98711 00982'),
    5: const SpeedDialEntry(key: 5, name: 'Shivi 🦋', number: '+91 98450 11223'),
  };

  static SpeedDialEntry? getEntry(int key) => _entries[key];

  static Map<int, SpeedDialEntry> getAll() => Map.unmodifiable(_entries);

  static void setEntry(int key, String name, String number) {
    if (key >= 1 && key <= 9) {
      _entries[key] = SpeedDialEntry(key: key, name: name, number: number);
    }
  }

  static void removeEntry(int key) {
    if (key > 1) {
      _entries.remove(key);
    }
  }
}
