import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import '../models/call_record.dart';
import '../services/telecom_service.dart';
import '../widgets/call_detail_bottom_sheet.dart';
import '../widgets/settings_dialog.dart';

class StackStyleConfig {
  final String id;
  final int number;
  final String name;
  final String hindiName;
  final String badge;
  final Color badgeBg;
  final Color badgeTextColor;
  final String description;
  final List<Color> highlightGradient;

  const StackStyleConfig({
    required this.id,
    required this.number,
    required this.name,
    required this.hindiName,
    required this.badge,
    required this.badgeBg,
    required this.badgeTextColor,
    required this.description,
    required this.highlightGradient,
  });
}

const List<StackStyleConfig> STACK_STYLES = [
  StackStyleConfig(
    id: 'ios-depth',
    number: 1,
    name: 'iOS Depth Stack',
    hindiName: 'क्लासिक iOS शेड',
    badge: 'iOS 18',
    badgeBg: Color(0x330284C7),
    badgeTextColor: Color(0xFF7DD3FC),
    description: 'Apple notification shade with 3D lip rollup and gentle scale compression.',
    highlightGradient: [Color(0xFF38BDF8), Color(0xFF3B82F6)],
  ),
  StackStyleConfig(
    id: 'coverflow-3d',
    number: 2,
    name: '3D Coverflow Deck',
    hindiName: 'कवरफ्लो 3D टिल्ट',
    badge: 'macOS 3D',
    badgeBg: Color(0x333B82F6),
    badgeTextColor: Color(0xFF93C5FD),
    description: 'Perspective 3D tilt with metallic edge reflection and depth perspective.',
    highlightGradient: [Color(0xFF60A5FA), Color(0xFF6366F1)],
  ),
  StackStyleConfig(
    id: 'cascade-waterfall',
    number: 3,
    name: 'Cascade Waterfall',
    hindiName: 'झरना कैस्केड वेव',
    badge: 'Fluid Wave',
    badgeBg: Color(0x3314B8A6),
    badgeTextColor: Color(0xFF5EEAD4),
    description: 'Fluid staggered waterfall with alternating wave offsets (translateX glide).',
    highlightGradient: [Color(0xFF2DD4BF), Color(0xFF10B981)],
  ),
  StackStyleConfig(
    id: 'cyberpunk-neon',
    number: 4,
    name: 'Cyberpunk Neon',
    hindiName: 'साइबरपंक नियॉन',
    badge: 'Cyber Neon',
    badgeBg: Color(0x33D946EF),
    badgeTextColor: Color(0xFFF0ABFC),
    description: 'Sci-fi stack with horizontal tilt, cyan & magenta edge glows.',
    highlightGradient: [Color(0xFF22D3EE), Color(0xFFE879F9)],
  ),
  StackStyleConfig(
    id: 'origami-fold',
    number: 5,
    name: 'Origami 3D Fold',
    hindiName: 'ओरिगेमी फोल्ड',
    badge: 'Papercraft',
    badgeBg: Color(0x33F59E0B),
    badgeTextColor: Color(0xFFFCD34D),
    description: 'Geometric papercraft folding motion as cards stack at top and bottom.',
    highlightGradient: [Color(0xFFFBBF24), Color(0xFFF97316)],
  ),
  StackStyleConfig(
    id: 'tinder-arc',
    number: 6,
    name: 'Tinder Arc Fan',
    hindiName: 'कार्ड्स फैन आर्क',
    badge: 'Cards Fan',
    badgeBg: Color(0x33F43F5E),
    badgeTextColor: Color(0xFFFDA4AF),
    description: 'Radial deck fanning like a hand of playing cards with smooth rotateZ arc curves.',
    highlightGradient: [Color(0xFFFB7185), Color(0xFFEF4444)],
  ),
  StackStyleConfig(
    id: 'accordion-spring',
    number: 7,
    name: 'Accordion Spring',
    hindiName: 'एलास्टिक स्प्रिंग बाउंस',
    badge: 'Elastic Bounce',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Dynamic elastic compression physics with playful spring recoil.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF22C55E)],
  ),
  StackStyleConfig(
    id: 'dynamic-island',
    number: 8,
    name: 'Dynamic Island',
    hindiName: 'डायनामिक कैप्सूल',
    badge: 'Apple Pill',
    badgeBg: Color(0x338B5CF6),
    badgeTextColor: Color(0xFFC4B5FD),
    description: 'Morphing rounded capsule pill stack with status ring beacons.',
    highlightGradient: [Color(0xFFA78BFA), Color(0xFF8B5CF6)],
  ),
  StackStyleConfig(
    id: 'visionos-glass',
    number: 9,
    name: 'VisionOS Frosted',
    hindiName: 'विज़नओएस ग्लास',
    badge: 'Spatial Glass',
    badgeBg: Color(0x336366F1),
    badgeTextColor: Color(0xFFA5B4FC),
    description: 'Spatial translucent frosted glass with iridescent rim highlights.',
    highlightGradient: [Color(0xFF818CF8), Color(0xFF38BDF8)],
  ),
  StackStyleConfig(
    id: 'charcoal-executive',
    number: 10,
    name: 'Charcoal Executive',
    hindiName: 'प्रीमियम चारकोल स्टैक',
    badge: 'Pro Executive',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Deep luxury matte obsidian charcoal with specular highlights and precision bevels.',
    highlightGradient: [Color(0xFF10B981), Color(0xFF059669)],
  ),
];

class StackedRecentsScreen extends StatefulWidget {
  final List<CallRecord> calls;
  final VoidCallback onRefresh;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const StackedRecentsScreen({
    super.key,
    required this.calls,
    required this.onRefresh,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<StackedRecentsScreen> createState() => _StackedRecentsScreenState();
}

class _StackedRecentsScreenState extends State<StackedRecentsScreen>
    with SingleTickerProviderStateMixin {
  late Ticker _ticker;
  double _scrollPos = 0.0;
  double _targetScroll = 0.0;
  double _velocity = 0.0;
  bool _isDragging = false;
  double _lastDragY = 0.0;
  DateTime _lastDragTime = DateTime.now();

  int _currentStyleIndex = 0;
  bool _isStackCollapsed = false;
  String _searchQuery = '';
  String _selectedFilter = 'all'; // 'all', 'missed', 'incoming', 'outgoing'

  // Card physics constants
  static const double cardHeight = 90.0;
  static const double cardGap = 8.0;
  static const double cardStep = cardHeight + cardGap; // 98.0
  static const double headerOffset = 10.0;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_onTick);
    _ticker.start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  void _onTick(Duration elapsed) {
    if (!mounted) return;

    final filtered = _getFilteredCalls();
    final maxScroll = math.max(
      0.0,
      headerOffset + filtered.length * cardStep - 320.0,
    );

    bool changed = false;

    // 1. Kinetic Momentum Decay
    if (!_isDragging && _velocity.abs() > 0.15) {
      _targetScroll += _velocity;
      _velocity *= 0.935; // smooth mobile deceleration
      if (_targetScroll < 0) {
        _targetScroll = 0;
        _velocity = 0;
      } else if (_targetScroll > maxScroll) {
        _targetScroll = maxScroll;
        _velocity = 0;
      }
      changed = true;
    } else if (!_isDragging) {
      _velocity = 0;
    }

    // 2. Continuous Spring Lerp Interpolation
    final diff = _targetScroll - _scrollPos;
    if (diff.abs() > 0.05) {
      _scrollPos += diff * 0.24;
      changed = true;
    } else if (_scrollPos != _targetScroll) {
      _scrollPos = _targetScroll;
      changed = true;
    }

    if (changed) {
      setState(() {});
    }
  }

  List<CallRecord> _getFilteredCalls() {
    return widget.calls.where((call) {
      if (_selectedFilter == 'missed') {
        if (call.type != CallType.missed && call.type != CallType.rejected) return false;
      } else if (_selectedFilter == 'incoming') {
        if (call.type != CallType.incoming) return false;
      } else if (_selectedFilter == 'outgoing') {
        if (call.type != CallType.outgoing) return false;
      }

      if (_searchQuery.trim().isNotEmpty) {
        final q = _searchQuery.toLowerCase();
        return call.name.toLowerCase().contains(q) ||
            call.number.contains(q);
      }
      return true;
    }).toList();
  }

  void _cycleNextStyle() {
    HapticFeedback.lightImpact();
    setState(() {
      _currentStyleIndex = (_currentStyleIndex + 1) % STACK_STYLES.length;
    });
  }

  void _restoreDefaultStyle() {
    HapticFeedback.mediumImpact();
    setState(() {
      _currentStyleIndex = 0;
    });
  }

  void _toggleStackCollapsed() {
    HapticFeedback.lightImpact();
    setState(() {
      _isStackCollapsed = !_isStackCollapsed;
    });
  }

  // Exact 3D math engine matching web preview
  Map<String, dynamic> _computeCardTransforms({
    required String styleId,
    required int index,
    required double naturalY,
    required double topBoundary,
    required double bottomBoundary,
    required double step,
  }) {
    double yPos = 0;
    double xPos = 0;
    double scale = 1.0;
    double rotateX = 0;
    double rotateY = 0;
    double rotateZ = 0;
    double skewX = 0;
    double opacity = 1.0;
    bool isStacked = false;
    Alignment transformOrigin = Alignment.center;
    int zIndex = 200 - index * 4;

    if (_isStackCollapsed) {
      const double deckBaseY = 16.0;
      final int stackIndex = math.min(index, 6);
      isStacked = true;
      zIndex = 200 - index * 4;
      yPos = deckBaseY + stackIndex * 16.0;
      scale = math.max(1.0 - stackIndex * 0.024, 0.88);
      rotateX = math.min(stackIndex * 2.0, 7.0);
      opacity = index > 6 ? 0.0 : math.max(1.0 - stackIndex * 0.11, 0.35);
    } else {
      if (naturalY < topBoundary) {
        // TOP STACK BUNCHING
        isStacked = true;
        final double topOverflow = topBoundary - naturalY;
        final double stackFactor = math.min(topOverflow / step, 3.5);
        yPos = topBoundary - math.pow(stackFactor, 0.7) * 12.0;
        scale = math.max(1.0 - stackFactor * 0.022, 0.94);
        rotateX = -math.min(stackFactor * 2.0, 5.0);
        opacity = math.max(1.0 - stackFactor * 0.32, 0.0);

        if (styleId == 'coverflow-3d') {
          rotateX = -math.min(stackFactor * 6.5, 20.0);
          scale = math.max(1.0 - stackFactor * 0.035, 0.88);
        } else if (styleId == 'origami-fold') {
          rotateX = -math.min(stackFactor * 10.0, 32.0);
          transformOrigin = Alignment.topCenter;
        } else if (styleId == 'tinder-arc') {
          rotateZ = ((index % 5) - 2) * math.min(stackFactor * 3.5, 9.0);
          xPos = ((index % 5) - 2) * math.min(stackFactor * 3.5, 10.0);
        } else if (styleId == 'cascade-waterfall') {
          xPos = (index % 2 == 0 ? -12.0 : 12.0) * math.min(stackFactor, 2.0);
        } else if (styleId == 'cyberpunk-neon') {
          rotateY = (index % 2 == 0 ? 5.0 : -5.0) * math.min(stackFactor, 2.2);
          skewX = (index % 2 == 0 ? 2.0 : -2.0) * math.min(stackFactor, 2.0);
        } else if (styleId == 'accordion-spring') {
          yPos = topBoundary - math.sin(math.min(stackFactor, 3.0) * 1.4) * 16.0;
          scale = math.max(1.0 - stackFactor * 0.04, 0.89);
        } else if (styleId == 'dynamic-island') {
          scale = math.max(1.0 - stackFactor * 0.05, 0.85);
          yPos = topBoundary - math.pow(stackFactor, 0.8) * 14.0;
        } else if (styleId == 'visionos-glass') {
          opacity = math.max(1.0 - stackFactor * 0.22, 0.25);
          scale = math.max(1.0 - stackFactor * 0.02, 0.95);
        } else if (styleId == 'charcoal-executive') {
          yPos = topBoundary - math.pow(stackFactor, 0.75) * 10.0;
        }
      } else if (naturalY > bottomBoundary) {
        // BOTTOM STACK OVERLAP
        isStacked = true;
        final double bottomOverflow = naturalY - bottomBoundary;
        final double stackFactor = bottomOverflow / step;
        yPos = bottomBoundary + (math.log(1.0 + stackFactor * 2.2) * 26.0);
        scale = math.max(1.0 - math.min(stackFactor, 4.0) * 0.02, 0.94);
        rotateX = math.min(stackFactor * 1.8, 5.0);
        opacity = math.max(1.0 - stackFactor * 0.07, 0.6);

        if (styleId == 'coverflow-3d') {
          rotateX = math.min(stackFactor * 5.5, 18.0);
          scale = math.max(1.0 - stackFactor * 0.03, 0.89);
        } else if (styleId == 'cascade-waterfall') {
          xPos = (index % 2 == 0 ? -10.0 : 10.0) * math.min(stackFactor, 2.0);
        } else if (styleId == 'origami-fold') {
          rotateX = math.min(stackFactor * 8.0, 26.0);
          transformOrigin = Alignment.bottomCenter;
        } else if (styleId == 'tinder-arc') {
          rotateZ = ((index % 5) - 2) * math.min(stackFactor * 2.5, 7.0);
          xPos = ((index % 5) - 2) * math.min(stackFactor * 3.0, 8.0);
        } else if (styleId == 'cyberpunk-neon') {
          rotateY = (index % 2 == 0 ? -4.0 : 4.0) * math.min(stackFactor, 1.8);
          skewX = (index % 2 == 0 ? -1.5 : 1.5) * math.min(stackFactor, 1.5);
        } else if (styleId == 'accordion-spring') {
          yPos = bottomBoundary + math.sin(math.min(stackFactor, 3.0) * 1.2) * 22.0;
          scale = math.max(1.0 - stackFactor * 0.035, 0.90);
        } else if (styleId == 'dynamic-island') {
          scale = math.max(1.0 - stackFactor * 0.045, 0.87);
        } else if (styleId == 'visionos-glass') {
          opacity = math.max(1.0 - stackFactor * 0.09, 0.55);
        } else if (styleId == 'charcoal-executive') {
          yPos = bottomBoundary + (math.log(1.0 + stackFactor * 2.4) * 24.0);
        }
      } else {
        // NATURAL IN-VIEW POSITION
        yPos = naturalY;
        scale = 1.0;
        opacity = 1.0;
        isStacked = false;
        rotateX = 0;
        rotateY = 0;
        rotateZ = 0;
        skewX = 0;
      }
    }

    return {
      'yPos': yPos,
      'xPos': xPos,
      'scale': scale,
      'rotateX': rotateX,
      'rotateY': rotateY,
      'rotateZ': rotateZ,
      'skewX': skewX,
      'opacity': opacity.clamp(0.0, 1.0),
      'isStacked': isStacked,
      'zIndex': zIndex,
      'transformOrigin': transformOrigin,
    };
  }

  void _showStyleSelectorSheet() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF141219),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (ctx) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Sheet Grab handle
              Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.style, color: Color(0xFF10B981), size: 18),
                      ),
                      const SizedBox(width: 10),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Card Stack Animation Styles',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '10 Distinct Physics-driven 3D Decks',
                            style: TextStyle(color: Colors.white38, fontSize: 11),
                          ),
                        ],
                      ),
                    ],
                  ),
                  TextButton.icon(
                    onPressed: () {
                      _restoreDefaultStyle();
                      Navigator.pop(ctx);
                    },
                    icon: const Icon(Icons.refresh, size: 14, color: Colors.blueAccent),
                    label: const Text('Reset', style: TextStyle(color: Colors.blueAccent, fontSize: 12)),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: ListView.builder(
                  itemCount: STACK_STYLES.length,
                  itemBuilder: (context, idx) {
                    final style = STACK_STYLES[idx];
                    final isSelected = idx == _currentStyleIndex;
                    return InkWell(
                      onTap: () {
                        HapticFeedback.selectionClick();
                        setState(() => _currentStyleIndex = idx);
                        Navigator.pop(ctx);
                      },
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? const Color(0xFF10B981).withOpacity(0.12)
                              : const Color(0xFF1F1D27).withOpacity(0.8),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF10B981).withOpacity(0.6)
                                : Colors.white.withOpacity(0.08),
                            width: isSelected ? 1.5 : 1.0,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                color: isSelected ? const Color(0xFF10B981) : Colors.white10,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Text(
                                  style.number.toString().padLeft(2, '0'),
                                  style: TextStyle(
                                    color: isSelected ? Colors.white : Colors.white70,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        style.name,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        '(${style.hindiName})',
                                        style: const TextStyle(color: Colors.white38, fontSize: 11),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    style.description,
                                    style: const TextStyle(color: Colors.white54, fontSize: 11),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: style.badgeBg,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                style.badge,
                                style: TextStyle(
                                  color: style.badgeTextColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  BoxDecoration _getCardBoxDecoration(String styleId, bool isMissed) {
    if (isMissed) {
      if (styleId == 'cyberpunk-neon') {
        return BoxDecoration(
          color: const Color(0xFF220D18).withOpacity(0.92),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.pinkAccent.withOpacity(0.6), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: Colors.pinkAccent.withOpacity(0.2),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        );
      }
      return BoxDecoration(
        color: const Color(0xFF241A24).withOpacity(0.92),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.redAccent.withOpacity(0.35), width: 1.0),
        boxShadow: [
          BoxShadow(
            color: Colors.redAccent.withOpacity(0.12),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      );
    }

    switch (styleId) {
      case 'coverflow-3d':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white.withOpacity(0.14),
              Colors.white.withOpacity(0.06),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.blueAccent.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(
              color: Colors.blueAccent.withOpacity(0.15),
              blurRadius: 12,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'cyberpunk-neon':
        return BoxDecoration(
          color: const Color(0xFF0E1019).withOpacity(0.92),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.cyanAccent.withOpacity(0.5), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: Colors.cyanAccent.withOpacity(0.25),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'cascade-waterfall':
        return BoxDecoration(
          color: const Color(0xFF112128).withOpacity(0.88),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.tealAccent.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(
              color: Colors.tealAccent.withOpacity(0.15),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'origami-fold':
        return BoxDecoration(
          color: const Color(0xFF201A14).withOpacity(0.88),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.amberAccent.withOpacity(0.35)),
          boxShadow: [
            BoxShadow(
              color: Colors.amberAccent.withOpacity(0.12),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'tinder-arc':
        return BoxDecoration(
          color: const Color(0xFF22131B).withOpacity(0.88),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.roseAccent.withOpacity(0.35)),
          boxShadow: [
            BoxShadow(
              color: Colors.roseAccent.withOpacity(0.15),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'accordion-spring':
        return BoxDecoration(
          color: const Color(0xFF122017).withOpacity(0.88),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF10B981).withOpacity(0.35)),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF10B981).withOpacity(0.15),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'dynamic-island':
        return BoxDecoration(
          color: Colors.black.withOpacity(0.92),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: Colors.purpleAccent.withOpacity(0.35)),
          boxShadow: [
            BoxShadow(
              color: Colors.purpleAccent.withOpacity(0.2),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'visionos-glass':
        return BoxDecoration(
          color: Colors.white.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.35)),
          boxShadow: [
            BoxShadow(
              color: Colors.white.withOpacity(0.1),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        );
      case 'charcoal-executive':
        return BoxDecoration(
          color: const Color(0xFF17171A).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.12)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'ios-depth':
      default:
        return BoxDecoration(
          color: Colors.white.withOpacity(0.09),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.12)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        );
    }
  }

  Widget _buildCardContent(CallRecord call, bool isMissed) {
    IconData typeIcon;
    Color typeColor;
    if (isMissed) {
      typeIcon = Icons.call_missed;
      typeColor = Colors.redAccent;
    } else if (call.type == CallType.outgoing) {
      typeIcon = Icons.call_made;
      typeColor = Colors.lightBlueAccent;
    } else {
      typeIcon = Icons.call_received;
      typeColor = const Color(0xFF10B981);
    }

    final durationText = call.duration > 0
        ? '${(call.duration ~/ 60)}m ${(call.duration % 60)}s'
        : '0s';

    return Row(
      children: [
        // Avatar
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isMissed
                  ? [Colors.redAccent.withOpacity(0.35), Colors.purpleAccent.withOpacity(0.2)]
                  : [const Color(0xFF10B981).withOpacity(0.35), Colors.blueAccent.withOpacity(0.2)],
            ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isMissed ? Colors.redAccent.withOpacity(0.3) : Colors.white12,
            ),
          ),
          child: Center(
            child: Text(
              call.name.isNotEmpty ? call.name[0].toUpperCase() : '?',
              style: TextStyle(
                color: isMissed ? Colors.redAccent : Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        // Name, Number & Info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      call.name,
                      style: TextStyle(
                        color: isMissed ? const Color(0xFFFF8B8B) : Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text(
                      'SIM ${call.simSlot}',
                      style: const TextStyle(color: Colors.white60, fontSize: 9, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 3),
              Row(
                children: [
                  Icon(typeIcon, color: typeColor, size: 12),
                  const SizedBox(width: 4),
                  Text(
                    call.number,
                    style: const TextStyle(color: Colors.white60, fontSize: 11, fontFamily: 'monospace'),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    '• $durationText',
                    style: const TextStyle(color: Colors.white38, fontSize: 10),
                  ),
                ],
              ),
            ],
          ),
        ),
        // Action Buttons: Copy & Direct Call CTA
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.copy, color: Colors.white38, size: 16),
              tooltip: 'Copy Number',
              onPressed: () {
                Clipboard.setData(ClipboardData(text: call.number));
                HapticFeedback.lightImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Copied ${call.number} to clipboard'),
                    duration: const Duration(seconds: 1),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
            ),
            InkWell(
              onTap: () {
                HapticFeedback.heavyImpact();
                widget.onCallNumber(call.number);
              },
              borderRadius: BorderRadius.circular(14),
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF10B981), Color(0xFF059669)],
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF10B981).withOpacity(0.4),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Center(
                  child: Icon(Icons.call, color: Colors.white, size: 20),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _getFilteredCalls();
    final currentStyle = STACK_STYLES[_currentStyleIndex];

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1B1822),
              Color(0xFF141219),
              Color(0xFF0D0C11),
            ],
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              // 1. Top Executive Control Strip
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFF141417).withOpacity(0.95),
                  border: const Border(
                    bottom: BorderSide(color: Colors.white10, width: 0.5),
                  ),
                ),
                child: Column(
                  children: [
                    // Row 1: Title, 10 Styles Dropdown, Cycle, Reset, Stack Toggle
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Title with pulse beacon
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: Color(0xFF10B981),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              'Recent Calls',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              '(${filtered.length})',
                              style: const TextStyle(
                                color: Colors.white38,
                                fontSize: 12,
                                fontFamily: 'monospace',
                              ),
                            ),
                          ],
                        ),
                        // Right Controls: 10 Styles Picker + Cycle Next + Restore + Stack Toggle
                        Row(
                          children: [
                            // 10 STYLES PICKER CHIP
                            InkWell(
                              onTap: _showStyleSelectorSheet,
                              borderRadius: BorderRadius.circular(12),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.06),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: Colors.white12),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.auto_awesome, color: Color(0xFF10B981), size: 12),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${currentStyle.number}. ${currentStyle.name.split(' ')[0]}',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(width: 4),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF10B981).withOpacity(0.2),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: const Text(
                                        '10',
                                        style: TextStyle(
                                          color: Color(0xFF10B981),
                                          fontSize: 9,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 2),
                                    const Icon(Icons.arrow_drop_down, color: Colors.white54, size: 14),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 4),
                            // Cycle next style button
                            IconButton(
                              icon: const Icon(Icons.shuffle, size: 16, color: Colors.white60),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                              tooltip: 'Cycle Next Style (1-10)',
                              onPressed: _cycleNextStyle,
                            ),
                            // Restore default style button
                            IconButton(
                              icon: const Icon(Icons.restore, size: 16, color: Colors.lightBlueAccent),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                              tooltip: 'Restore Style 1 (iOS Depth)',
                              onPressed: _restoreDefaultStyle,
                            ),
                            // Stack Deck vs Fan Out toggle button
                            InkWell(
                              onTap: _toggleStackCollapsed,
                              borderRadius: BorderRadius.circular(10),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                decoration: BoxDecoration(
                                  color: _isStackCollapsed
                                      ? Colors.amber.withOpacity(0.25)
                                      : Colors.white.withOpacity(0.06),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: _isStackCollapsed ? Colors.amber : Colors.white12,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.layers,
                                      size: 13,
                                      color: _isStackCollapsed ? Colors.amber : Colors.white70,
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      _isStackCollapsed ? 'Fan Out' : 'Stack',
                                      style: TextStyle(
                                        color: _isStackCollapsed ? Colors.amber : Colors.white70,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 4),
                            // Test incoming call button
                            if (widget.onSimulateIncoming != null)
                              IconButton(
                                icon: const Icon(Icons.phone_callback, size: 15, color: Color(0xFF10B981)),
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(minWidth: 26, minHeight: 26),
                                tooltip: 'Test Incoming Call UI',
                                onPressed: widget.onSimulateIncoming,
                              ),
                            // Settings Button
                            IconButton(
                              icon: const Icon(Icons.settings_outlined, size: 16, color: Colors.white70),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 26, minHeight: 26),
                              tooltip: 'Dialer Settings',
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (ctx) => DialerSettingsDialog(
                                    onSimulateIncoming: widget.onSimulateIncoming,
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),

                    // Row 2: Search Input & Filter Chips
                    Row(
                      children: [
                        // Search Box
                        Expanded(
                          child: Container(
                            height: 34,
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1E1C25),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: Colors.white10),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.search, color: Colors.white38, size: 16),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: TextField(
                                    style: const TextStyle(color: Colors.white, fontSize: 12),
                                    decoration: const InputDecoration(
                                      hintText: 'Search recents...',
                                      hintStyle: TextStyle(color: Colors.white30, fontSize: 12),
                                      border: InputBorder.none,
                                      isDense: true,
                                      contentPadding: EdgeInsets.zero,
                                    ),
                                    onChanged: (val) => setState(() => _searchQuery = val),
                                  ),
                                ),
                                if (_searchQuery.isNotEmpty)
                                  GestureDetector(
                                    onTap: () => setState(() => _searchQuery = ''),
                                    child: const Icon(Icons.close, color: Colors.white54, size: 14),
                                  ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        // Filter Pills
                        _buildFilterPill('all', 'All'),
                        const SizedBox(width: 4),
                        _buildFilterPill('missed', 'Missed'),
                        const SizedBox(width: 4),
                        _buildFilterPill('incoming', 'In'),
                        const SizedBox(width: 4),
                        _buildFilterPill('outgoing', 'Out'),
                      ],
                    ),
                  ],
                ),
              ),

              // 2. 3D Kinetic Card Stack Stage Viewport
              Expanded(
                child: filtered.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.phone_missed, color: Colors.white.withOpacity(0.15), size: 54),
                            const SizedBox(height: 12),
                            const Text(
                              'No recent calls found',
                              style: TextStyle(color: Colors.white54, fontSize: 14),
                            ),
                          ],
                        ),
                      )
                    : LayoutBuilder(
                        builder: (context, constraints) {
                          final double containerHeight = constraints.maxHeight;
                          final double topStackBoundary = headerOffset;
                          final double bottomStackBoundary = containerHeight - 140.0;
                          final double maxScroll = math.max(
                            0.0,
                            headerOffset + filtered.length * cardStep - containerHeight + 70.0,
                          );

                          return GestureDetector(
                            onVerticalDragStart: (details) {
                              _isDragging = true;
                              _velocity = 0;
                              _lastDragY = details.localPosition.dy;
                              _lastDragTime = DateTime.now();
                            },
                            onVerticalDragUpdate: (details) {
                              final currentY = details.localPosition.dy;
                              final now = DateTime.now();
                              final dt = math.max(
                                1,
                                now.difference(_lastDragTime).inMilliseconds,
                              );
                              final deltaY = _lastDragY - currentY;
                              final instantVelocity = (deltaY / dt) * 16.0;
                              _velocity = _velocity * 0.35 + instantVelocity * 0.65;
                              _lastDragY = currentY;
                              _lastDragTime = now;

                              _targetScroll = (_targetScroll + deltaY).clamp(0.0, maxScroll);
                              _scrollPos = _targetScroll;
                              setState(() {});
                            },
                            onVerticalDragEnd: (details) {
                              _isDragging = false;
                              _velocity = _velocity.clamp(-26.0, 26.0);
                            },
                            child: Container(
                              color: Colors.transparent,
                              child: Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  for (int i = 0; i < filtered.length; i++) ...[
                                    _buildCardWidget(
                                      index: i,
                                      call: filtered[i],
                                      currentStyle: currentStyle,
                                      topBoundary: topStackBoundary,
                                      bottomBoundary: bottomStackBoundary,
                                      step: cardStep,
                                      containerWidth: constraints.maxWidth,
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCardWidget({
    required int index,
    required CallRecord call,
    required StackStyleConfig currentStyle,
    required double topBoundary,
    required double bottomBoundary,
    required double step,
    required double containerWidth,
  }) {
    final double naturalY = headerOffset + index * step - _scrollPos;
    final transforms = _computeCardTransforms(
      styleId: currentStyle.id,
      index: index,
      naturalY: naturalY,
      topBoundary: topBoundary,
      bottomBoundary: bottomBoundary,
      step: step,
    );

    final double yPos = transforms['yPos'];
    final double xPos = transforms['xPos'];
    final double scale = transforms['scale'];
    final double rotateX = transforms['rotateX'];
    final double rotateY = transforms['rotateY'];
    final double rotateZ = transforms['rotateZ'];
    final double skewX = transforms['skewX'];
    final double opacity = transforms['opacity'];
    final Alignment origin = transforms['transformOrigin'];
    final bool isMissed = call.type == CallType.missed || call.type == CallType.rejected;

    if (opacity <= 0.01) {
      return const SizedBox.shrink();
    }

    final matrix = Matrix4.identity()
      ..setEntry(3, 2, 0.0015) // perspective depth
      ..translate(xPos, yPos, 0.0)
      ..scale(scale, scale, 1.0)
      ..rotateX(rotateX * math.pi / 180.0)
      ..rotateY(rotateY * math.pi / 180.0)
      ..rotateZ(rotateZ * math.pi / 180.0);

    if (skewX != 0.0) {
      matrix.setEntry(0, 1, math.tan(skewX * math.pi / 180.0));
    }

    return Positioned(
      top: 0,
      left: 14,
      right: 14,
      child: Transform(
        transform: matrix,
        alignment: origin,
        child: Opacity(
          opacity: opacity,
          child: GestureDetector(
            onTap: () {
              if (_isStackCollapsed) {
                _toggleStackCollapsed();
              } else {
                HapticFeedback.lightImpact();
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  builder: (ctx) => CallDetailBottomSheet(
                    call: call,
                    onCallNumber: widget.onCallNumber,
                    onDeleteCall: (id) {
                      setState(() {
                        widget.calls.removeWhere((c) => c.id == id);
                      });
                    },
                  ),
                );
              }
            },
            child: Container(
              height: cardHeight,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: _getCardBoxDecoration(currentStyle.id, isMissed),
              child: _buildCardContent(call, isMissed),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFilterPill(String key, String label) {
    final isSelected = _selectedFilter == key;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _selectedFilter = key);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF10B981) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white60,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
