import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/contact.dart';
import '../services/speed_dial_service.dart';
import '../widgets/settings_dialog.dart';

class T9DialpadScreen extends StatefulWidget {
  final List<ContactModel> contacts;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const T9DialpadScreen({
    super.key,
    required this.contacts,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<T9DialpadScreen> createState() => _T9DialpadScreenState();
}

class _T9DialpadScreenState extends State<T9DialpadScreen> {
  String _digits = '';
  int _selectedSim = 1;

  final List<Map<String, String>> _speedDialFavorites = [
    {'label': 'Mom ❤️', 'number': '+91 98201 45892', 'color': '0xFFEC4899'},
    {'label': 'Sanib A.', 'number': '+91 97654 21980', 'color': '0xFF3B82F6'},
    {'label': 'Mo Faisal', 'number': '+91 98711 00982', 'color': '0xFF10B981'},
    {'label': 'Shivi 🦋', 'number': '+91 98450 11223', 'color': '0xFF8B5CF6'},
    {'label': '112 SOS', 'number': '112', 'color': '0xFFEF4444'},
  ];

  final List<String> _recentSearches = ['98201', 'Sanib', 'Priya', '98711'];

  final Map<String, String> _t9Map = {
    '1': '',
    '2': 'ABC',
    '3': 'DEF',
    '4': 'GHI',
    '5': 'JKL',
    '6': 'MNO',
    '7': 'PQRS',
    '8': 'TUV',
    '9': 'WXYZ',
    '*': '',
    '0': '+',
    '#': '',
  };

  void _onDigitPress(String digit) {
    HapticFeedback.lightImpact();
    setState(() {
      _digits += digit;
    });
  }

  void _onBackspace() {
    HapticFeedback.lightImpact();
    if (_digits.isNotEmpty) {
      setState(() {
        _digits = _digits.substring(0, _digits.length - 1);
      });
    }
  }

  void _onClearAll() {
    HapticFeedback.mediumImpact();
    setState(() {
      _digits = '';
    });
  }

  List<ContactModel> _getMatchedContacts() {
    if (_digits.isEmpty) return [];
    final q = _digits.toLowerCase();
    return widget.contacts.where((c) {
      final cleanNum = c.number.replaceAll(RegExp(r'[^\d]'), '');
      return cleanNum.contains(q) || c.name.toLowerCase().contains(q);
    }).take(3).toList();
  }

  void _openSettings() {
    showDialog(
      context: context,
      builder: (ctx) => DialerSettingsDialog(
        onSimulateIncoming: widget.onSimulateIncoming,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final matches = _getMatchedContacts();

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1B1822),
              Color(0xFF141219),
              Color(0xFF0D0C11),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // 1. Top Executive Bar: SIM Selector & Quick Action Icons
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Dual SIM Pills
                    Row(
                      children: [
                        _buildSimPill(1, 'SIM 1 (Jio 5G)'),
                        const SizedBox(width: 8),
                        _buildSimPill(2, 'SIM 2 (Airtel)'),
                      ],
                    ),

                    // Right Quick Icons: Test Call & Settings
                    Row(
                      children: [
                        // Incoming call tester chip
                        if (widget.onSimulateIncoming != null)
                          InkWell(
                            onTap: widget.onSimulateIncoming,
                            borderRadius: BorderRadius.circular(12),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                              margin: const EdgeInsets.only(right: 6),
                              decoration: BoxDecoration(
                                color: const Color(0xFF10B981).withOpacity(0.12),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: const Color(0xFF10B981).withOpacity(0.3)),
                              ),
                              child: const Row(
                                children: [
                                  Icon(Icons.phone_in_talk, color: Color(0xFF10B981), size: 12),
                                  SizedBox(width: 4),
                                  Text(
                                    'Test Call',
                                    style: TextStyle(
                                      color: Color(0xFF10B981),
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                        // Settings Icon
                        IconButton(
                          icon: const Icon(Icons.settings_outlined, color: Colors.white70, size: 20),
                          tooltip: 'Dialer Settings',
                          onPressed: _openSettings,
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Speed Dial & Recent query chips if digits is empty
              if (_digits.isEmpty) ...[
                // Speed Dial Row
                Container(
                  height: 36,
                  margin: const EdgeInsets.only(bottom: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: _speedDialFavorites.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, idx) {
                      final fav = _speedDialFavorites[idx];
                      final color = Color(int.parse(fav['color']!));
                      return InkWell(
                        onTap: () {
                          HapticFeedback.heavyImpact();
                          widget.onCallNumber(fav['number']!);
                        },
                        borderRadius: BorderRadius.circular(14),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: color.withOpacity(0.35)),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.star, color: color, size: 12),
                              const SizedBox(width: 4),
                              Text(
                                fav['label']!,
                                style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),

                // Recent Searches Row
                Container(
                  height: 30,
                  margin: const EdgeInsets.only(bottom: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: _recentSearches.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, idx) {
                      final item = _recentSearches[idx];
                      return InkWell(
                        onTap: () {
                          HapticFeedback.selectionClick();
                          setState(() => _digits = item);
                        },
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFF24222C),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.white10),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.history, color: Colors.white38, size: 11),
                              const SizedBox(width: 4),
                              Text(
                                item,
                                style: const TextStyle(color: Colors.white70, fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],

              // 2. Matched Contacts Preview Card (T9 Search Stage)
              if (matches.isNotEmpty)
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF201E27).withOpacity(0.9),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0xFF10B981).withOpacity(0.3)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    children: matches.map((m) {
                      return InkWell(
                        onTap: () => widget.onCallNumber(m.number),
                        borderRadius: BorderRadius.circular(12),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 6),
                          child: Row(
                            children: [
                              Container(
                                width: 34,
                                height: 34,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF10B981).withOpacity(0.18),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Center(
                                  child: Text(
                                    m.initials,
                                    style: const TextStyle(
                                      color: Color(0xFF10B981),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      m.name,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                      ),
                                    ),
                                    Text(
                                      m.number,
                                      style: const TextStyle(
                                        color: Colors.white54,
                                        fontSize: 11,
                                        fontFamily: 'monospace',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF10B981).withOpacity(0.2),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.call, color: Color(0xFF10B981), size: 14),
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),

              const Spacer(),

              // 3. Dial Display: Formatted digits with paste / clear buttons
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                child: Column(
                  children: [
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      reverse: true,
                      child: Text(
                        _digits.isEmpty ? ' ' : _digits,
                        style: TextStyle(
                          fontSize: _digits.length > 12 ? 28 : 36,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    if (_digits.isNotEmpty)
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(
                            onTap: () {
                              HapticFeedback.lightImpact();
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Adding $_digits to device contacts...'),
                                  duration: const Duration(seconds: 1),
                                ),
                              );
                            },
                            borderRadius: BorderRadius.circular(12),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.06),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Row(
                                children: [
                                  Icon(Icons.person_add_outlined, size: 13, color: Color(0xFF10B981)),
                                  SizedBox(width: 4),
                                  Text(
                                    'Add to Contacts',
                                    style: TextStyle(
                                      color: Color(0xFF10B981),
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ),

              const SizedBox(height: 10),

              // 4. Squircle Dialpad 4x3 Grid (Dusk Mauve Frosted Squircles)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Column(
                  children: [
                    _buildSquircleRow(['1', '2', '3']),
                    const SizedBox(height: 10),
                    _buildSquircleRow(['4', '5', '6']),
                    const SizedBox(height: 10),
                    _buildSquircleRow(['7', '8', '9']),
                    const SizedBox(height: 10),
                    _buildSquircleRow(['*', '0', '#']),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              // 5. Bottom Action Row: Call CTA & Backspace Button
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 36),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // Empty spacer to balance backspace
                    const SizedBox(width: 54),

                    // Glowing Emerald Squircle Call CTA
                    InkWell(
                      onTap: () {
                        if (_digits.isNotEmpty) {
                          HapticFeedback.heavyImpact();
                          widget.onCallNumber(_digits);
                        }
                      },
                      borderRadius: BorderRadius.circular(24),
                      child: Container(
                        width: 88,
                        height: 58,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [Color(0xFF10B981), Color(0xFF059669)],
                          ),
                          borderRadius: BorderRadius.circular(22),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF10B981).withOpacity(0.45),
                              blurRadius: 16,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Icon(Icons.call, color: Colors.white, size: 28),
                        ),
                      ),
                    ),

                    // Squircle Backspace button
                    _digits.isNotEmpty
                        ? GestureDetector(
                            onTap: _onBackspace,
                            onLongPress: _onClearAll,
                            child: Container(
                              width: 54,
                              height: 54,
                              decoration: BoxDecoration(
                                color: const Color(0xFF24222C),
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(color: Colors.white10),
                              ),
                              child: const Center(
                                child: Icon(Icons.backspace_outlined, color: Colors.white70, size: 20),
                              ),
                            ),
                          )
                        : const SizedBox(width: 54),
                  ],
                ),
              ),

              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSimPill(int slot, String label) {
    final isSelected = _selectedSim == slot;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _selectedSim = slot);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF10B981).withOpacity(0.2) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isSelected ? const Color(0xFF10B981) : Colors.white12,
            width: isSelected ? 1.2 : 0.8,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? const Color(0xFF10B981) : Colors.white70,
            fontSize: 11,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildSquircleRow(List<String> keys) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: keys.map((k) => _buildSquircleButton(k)).toList(),
    );
  }

  Widget _buildSquircleButton(String key) {
    final sub = _t9Map[key] ?? '';
    return InkWell(
      onTap: () => _onDigitPress(key),
      onLongPress: () {
        if (key == '0') {
          _onDigitPress('+');
        } else if (key == '1') {
          HapticFeedback.heavyImpact();
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Calling Voicemail (*123#)...')),
          );
          widget.onCallNumber('*123#');
        } else {
          final intKey = int.tryParse(key);
          if (intKey != null && intKey >= 2 && intKey <= 9) {
            final entry = SpeedDialService.getEntry(intKey);
            if (entry != null) {
              HapticFeedback.heavyImpact();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('⚡ Speed Dial #$intKey: Calling ${entry.name} (${entry.number})'),
                  duration: const Duration(seconds: 2),
                ),
              );
              widget.onCallNumber(entry.number);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Speed Dial key $intKey is not assigned yet. Set it in Settings!'),
                ),
              );
            }
          }
        }
      },
      borderRadius: BorderRadius.circular(22),
      child: Container(
        width: 76,
        height: 62,
        decoration: BoxDecoration(
          color: const Color(0xFF221F2B),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: Colors.white.withOpacity(0.08),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              key,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w700,
                color: Colors.white,
                height: 1.1,
              ),
            ),
            if (sub.isNotEmpty)
              Text(
                sub,
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: Colors.white38,
                  letterSpacing: 1.5,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
